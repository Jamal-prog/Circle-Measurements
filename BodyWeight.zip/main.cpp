#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char* argv[]) {
	float weight;
	float height;
  float bmi;
  printf(" Enter the weight in kilogram >>>   " );
	scanf("%f", &weight);
  printf(" Enter the height in meters >>>   " );
  scanf("%f", &height);
  bmi = weight/(height*height);
  printf(" BMI = %f ", bmi);
  while (1)
  {
  if(bmi< 18)
    printf(" BMI < 18 -> Underweight");
  if(bmi >= 18; bmi <25 )
    printf(" BMI >= 18 and BMI < 25 -> Normal ");
  if(bmi >= 25; bmi < 30 )
    printf(" BMI >= 25 and BMI < 30 -> Overweight ");
  if(bmi >= 30 )
    printf(" BMI >= 30 -> Obese ");

   break; 
  }
  return 0;
}