#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char* argv[]) {
	float radius;
	float circumference;
	printf(" Enter the radius >>>   " );
	scanf("%f", &radius);
  float diameter;
  diameter = 2 * radius;
  printf(" Diameter = %f ", diameter);
  circumference = 3.14159 *2*radius;
  printf(" Circumference = %f ", circumference);
  float area;
  area = 3.14159 *(radius*radius);
  printf("Area = %f ", area);
  
  
}